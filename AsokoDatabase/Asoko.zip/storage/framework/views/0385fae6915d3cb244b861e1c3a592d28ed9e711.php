<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center mt-2 mb-2" href="index.html">
        
        <div class="sidebar-brand-text mx-3">Asoko Database Management</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">


    <!-- Nav Item - Dashboard -->
    <li class="nav-item <?php if($active == " dashboard"): ?>active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('home.index')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Home</span></a>
    </li>
    <li class="nav-item <?php if($active == " clients"): ?>active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('clients.index')); ?>">
            <i class="fas fa-calendar"></i>
            <span>Clients</span></a>
    </li>
    <li class="nav-item <?php if($active == " agents"): ?>active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('agents.index')); ?>">
            <i class="fas fa-clipboard-list"></i>
            <span>Agents</span></a>
    </li>
    <li class="nav-item  <?php if($active == " gadgets"): ?>active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('gadgets.index')); ?>">
            <i class="fas fa-space-shuttle"></i>
            <span>Gadgets</span></a>
    </li>
    <li class="nav-item  <?php if($active == " transactions"): ?>active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('transactions.index')); ?>">
            <i class="fas fa-dollar-sign"></i>
            <span>Astrack Transactions</span></a>
    </li>
    <li class="nav-item  <?php if($active == " mpesa-transaction"): ?>active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('mpesa-transactions.index')); ?>">
            <i class="fas fa-dollar-sign"></i>
            <span>M-Pesa Transactions</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('register')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Register New Admin</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    

</ul>
<!-- End of Sidebar --><?php /**PATH C:\Users\Gathaiya\Desktop\Projects\Web\AsokoDB\AsokoDatabase\resources\views/side-pane.blade.php ENDPATH**/ ?>